package com.hmapps.munch_hub_customer;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
