import 'package:get/get.dart';

class GlobalVariables {
  static RxString token = "".obs;
  static RxInt selectedIndex = 2.obs;
  static RxString userFirstName = "".obs;
  static RxString userLastName = "".obs;
  static RxString userEmail = "".obs;
  static RxInt cartCount = 0.obs;
}
